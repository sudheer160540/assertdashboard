import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cdk-pricing-plan',
  templateUrl: './pricing-plan.component.html',
  styleUrls: ['./pricing-plan.component.scss']
})
export class PricingPlanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
